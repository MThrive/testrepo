# Display new output
print(" New Python File")
print(" Maya Is Amazing")
